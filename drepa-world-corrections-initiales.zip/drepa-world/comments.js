
/* =========================================
   DREPA-WORLD — COMMENTAIRES ET RÉACTIONS
========================================= */

export function initializeComments(context) {
  const {
    apiRequest,
    escapeHTML,
    getInitials,
    formatDate
  } = context;

  const loadedComments = new Set();
  const loadingComments = new Set();

  /* =====================================
     AFFICHAGE DES COMMENTAIRES
  ===================================== */

  function createCommentElement(comment) {
    const element = document.createElement("div");

    element.className = "post-comment";

    const author = escapeHTML(comment.author || "Membre");
    const initials = escapeHTML(
      getInitials(comment.author || "Membre")
    );

    const date = escapeHTML(formatDate(comment.created_at));

    const content = escapeHTML(comment.content || "")
      .replace(/\r\n/g, "\n")
      .replace(/\r/g, "\n")
      .replace(/\n/g, "<br>");

    element.innerHTML = `
      <div class="comment-avatar">${initials}</div>

      <div class="comment-body">
        <div class="comment-bubble">
          <strong>${author}</strong>
          <p>${content}</p>
        </div>

        <div class="comment-meta">
          <span>${date}</span>
        </div>
      </div>
    `;

    return element;
  }

  function renderComments(container, comments) {
    let list = container.querySelector(".comments-list");

    if (!list) {
      container.replaceChildren();

      list = document.createElement("div");
      list.className = "comments-list";

      container.appendChild(list);
    }

    list.replaceChildren();

    if (comments.length === 0) {
      const empty = document.createElement("p");

      empty.className = "comments-empty";
      empty.textContent = "Aucun commentaire pour le moment.";

      list.appendChild(empty);
      return;
    }

    comments.forEach(comment => {
      list.appendChild(createCommentElement(comment));
    });
  }

  function showCommentMessage(container, message) {
    let notice = container.querySelector(".comment-message");

    if (!notice) {
      notice = document.createElement("p");
      notice.className = "comment-message";
      container.prepend(notice);
    }

    notice.textContent = message;
  }

  /* =====================================
     CHARGEMENT DES COMMENTAIRES
  ===================================== */

  async function loadComments(postId, container) {
    const id = String(postId);

    if (!container || loadingComments.has(id)) {
      return false;
    }

    if (loadedComments.has(id)) {
      return true;
    }

    loadingComments.add(id);

    const loading = document.createElement("p");

    loading.className = "comments-empty";
    loading.textContent = "Chargement des commentaires...";

    container.replaceChildren(loading);

    try {
      const data = await apiRequest(
        `/posts/${encodeURIComponent(id)}/comments`
      );

      const comments = Array.isArray(data.comments)
        ? data.comments
        : [];

      renderComments(container, comments);

      loadedComments.add(id);

      return true;

    } catch (error) {
      console.error("Chargement des commentaires :", error);

      container.replaceChildren();

      showCommentMessage(
        container,
        "Impossible de charger les commentaires. Réessayez."
      );

      return false;

    } finally {
      loadingComments.delete(id);
    }
  }

  /* =====================================
     MISE À JOUR DU COMPTEUR
  ===================================== */

  function updateCommentCount(postElement, count) {
    const counter = postElement.querySelector(
      ".post-comment-count"
    );

    if (!counter) return;

    counter.textContent = count > 0
      ? `${count} commentaire(s)`
      : "";
  }

  /* =====================================
     ENVOI D'UN COMMENTAIRE
  ===================================== */

  async function submitComment(
    postId,
    postElement,
    input,
    button,
    container
  ) {
    const content = input.value.trim();

    if (!content) {
      showCommentMessage(
        container,
        "Écrivez votre commentaire avant de l'envoyer."
      );

      return;
    }

    button.disabled = true;
    button.textContent = "Envoi...";

    try {
      await apiRequest(
        `/posts/${encodeURIComponent(postId)}/comments`,
        {
          method: "POST",
          body: { content }
        }
      );

      const data = await apiRequest(
        `/posts/${encodeURIComponent(postId)}/comments`
      );

      const comments = Array.isArray(data.comments)
        ? data.comments
        : [];

      renderComments(container, comments);

      loadedComments.add(String(postId));

      updateCommentCount(postElement, comments.length);

      input.value = "";

    } catch (error) {
      console.error("Envoi du commentaire :", error);

      showCommentMessage(
        container,
        error.message || "Impossible d'envoyer votre commentaire."
      );

    } finally {
      button.disabled = false;
      button.textContent = "Envoyer";
    }
  }

  /* =====================================
     FORMULAIRE DE COMMENTAIRE
  ===================================== */

  function openCommentForm(
    postId,
    postElement,
    container
  ) {
    if (!container) return;

    const existingForm = container.querySelector(
      ".comment-form"
    );

    if (existingForm) {
      existingForm.querySelector("textarea")?.focus();
      return;
    }

    const form = document.createElement("form");

    form.className = "comment-form";

    form.innerHTML = `
      <textarea
        rows="2"
        maxlength="2000"
        placeholder="Écrire un commentaire..."
        aria-label="Votre commentaire"
        required
      ></textarea>

      <button type="submit" class="comment-submit">
        Envoyer
      </button>
    `;

    const textarea = form.querySelector("textarea");
    const button = form.querySelector("button");

    form.addEventListener("submit", event => {
      event.preventDefault();

      submitComment(
        postId,
        postElement,
        textarea,
        button,
        container
      );
    });

    container.appendChild(form);

    textarea.focus();
  }

  /* =====================================
     RÉACTIONS
  ===================================== */

  async function sendReaction(button) {
    if (button.disabled) return;

    const postId = button.dataset.postId;
    const reaction = button.dataset.reaction;

    if (!postId || !reaction) return;

    const labels = {
      like: "J'aime",
      support: "Soutenir",
      courage: "Courage"
    };

    const successLabels = {
      like: "Envoyé",
      support: "Soutien envoyé",
      courage: "Courage envoyé"
    };

    button.disabled = true;
    button.classList.add("is-loading");

    try {
      await apiRequest(
        `/posts/${encodeURIComponent(postId)}/reactions`,
        {
          method: "POST",
          body: { reaction }
        }
      );

      button.classList.add("sent");
      button.textContent = successLabels[reaction] || "Envoyé";

      window.setTimeout(() => {
        button.classList.remove("sent");
        button.textContent = labels[reaction] || "Réagir";
      }, 1800);

    } catch (error) {
      console.error("Envoi de la réaction :", error);

      button.textContent = "Réessayer";

      window.setTimeout(() => {
        button.textContent = labels[reaction] || "Réagir";
      }, 1800);

    } finally {
      button.disabled = false;
      button.classList.remove("is-loading");
    }
  }

  /* =====================================
     GESTION DES CLICS
  ===================================== */

  document.addEventListener("click", async event => {
    const button = event.target.closest("[data-action]");

    if (!button) return;

    const action = button.dataset.action;
    const postId = button.dataset.postId;

    if (!postId) return;

    const postElement = button.closest(".post-card");

    if (!postElement) return;

    if (action === "reaction") {
      await sendReaction(button);
      return;
    }

    if (action === "comments") {
      const container = Array.from(
        postElement.querySelectorAll("[data-comments-container]")
      ).find(element => {
        return element.dataset.commentsContainer === String(postId);
      });

      if (!container) return;

      const isExpanded =
        button.getAttribute("aria-expanded") === "true";

      if (isExpanded) {
        button.setAttribute("aria-expanded", "false");
        container.hidden = true;
        return;
      }

      button.setAttribute("aria-expanded", "true");
      container.hidden = false;

      await loadComments(postId, container);

      openCommentForm(
        postId,
        postElement,
        container
      );
    }
  });

  return {
    loadComments
  };
       }
     
