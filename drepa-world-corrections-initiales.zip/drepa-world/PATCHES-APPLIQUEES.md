# DREPA-WORLD — première correction

Fichiers corrigés :
- `worker (2).js` : limite des publications portée à 5 000 caractères ; limite des commentaires portée à 2 000 caractères.
- `feed.js` : le compteur du fil lit désormais `reactions_count`, le champ réellement renvoyé par l’API, et affiche « réaction(s) ».
- `comments.js` : la limite de saisie du commentaire est alignée sur 2 000 caractères côté interface.

Le champ de publication dans `espace (2).html` était déjà limité à 5 000 caractères : aucune modification n’était nécessaire.

## À faire avant mise en production
1. Remplacer les fichiers correspondants dans le dépôt par les versions corrigées.
2. Vérifier que le fichier `worker.js` utilisé par Wrangler reçoit le contenu de `worker (2).js`.
3. Tester publication, commentaires et réactions avec un compte membre.
4. Déployer le Worker uniquement après validation.

Aucun déploiement Cloudflare ni commit GitHub n’a été effectué depuis cette session.
